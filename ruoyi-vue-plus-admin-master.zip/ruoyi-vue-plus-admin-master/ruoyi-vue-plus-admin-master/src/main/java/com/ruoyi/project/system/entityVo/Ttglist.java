package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("ttglist")
public class Ttglist implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("matchId")
    private Long matchId;

    @TableField("s3")
    private String s3;

    @TableField("s4")
    private String s4;

    @TableField("updateDate")
    private LocalDateTime updateDate;

    @TableField("s5")
    private String s5;

    @TableField("s6f")
    private String s6f;

    @TableField("s6")
    private String s6;

    @TableField("s7f")
    private String s7f;

    @TableField("s4f")
    private String s4f;

    @TableField("s7")
    private String s7;

    @TableField("s5f")
    private String s5f;

    @TableField("s2f")
    private String s2f;

    @TableField("s3f")
    private String s3f;

    @TableField("s0f")
    private String s0f;

    @TableField("s1f")
    private String s1f;

    @TableField("updateTime")
    private String updateTime;

    @TableField("goalLine")
    private String goalLine;

    @TableField("s0")
    private String s0;

    @TableField("s1")
    private String s1;

    @TableField("s2")
    private String s2;
}
