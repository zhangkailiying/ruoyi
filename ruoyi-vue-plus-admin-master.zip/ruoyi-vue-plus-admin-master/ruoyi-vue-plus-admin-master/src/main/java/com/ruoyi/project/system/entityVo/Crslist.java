package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("crslist")
public class Crslist implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("s05s00")
    private String s05s00;

    @TableField("matchId")
    private Long matchId;

    @TableField("s99sd")
    private String s99sd;

    @TableField("s02s00f")
    private String s02s00f;

    @TableField("s99sh")
    private String s99sh;

    @TableField("s01s00")
    private String s01s00;

    @TableField("s05s02")
    private String s05s02;

    @TableField("s05s01")
    private String s05s01;

    @TableField("s99sa")
    private String s99sa;

    @TableField("s00s03f")
    private String s00s03f;

    @TableField("s02s04f")
    private String s02s04f;

    @TableField("s04s01f")
    private String s04s01f;

    @TableField("s03s00f")
    private String s03s00f;

    @TableField("s01s03f")
    private String s01s03f;

    @TableField("s02s04")
    private String s02s04;

    @TableField("s02s05")
    private String s02s05;

    @TableField("s02s02")
    private String s02s02;

    @TableField("s02s03")
    private String s02s03;

    @TableField("s05s01f")
    private String s05s01f;

    @TableField("s02s00")
    private String s02s00;

    @TableField("s02s01")
    private String s02s01;

    @TableField("s02s05f")
    private String s02s05f;

    @TableField("s00s02f")
    private String s00s02f;

    @TableField("s02s01f")
    private String s02s01f;

    @TableField("s04s00f")
    private String s04s00f;

    @TableField("goalLine")
    private String goalLine;

    @TableField("s03s01f")
    private String s03s01f;

    @TableField("s99sdf")
    private String s99sdf;

    @TableField("s99shf")
    private String s99shf;

    @TableField("s01s02f")
    private String s01s02f;

    @TableField("s03s03")
    private String s03s03;

    @TableField("s05s00f")
    private String s05s00f;

    @TableField("updateDate")
    private LocalDateTime updateDate;

    @TableField("s03s01")
    private String s03s01;

    @TableField("s03s02")
    private String s03s02;

    @TableField("s03s00")
    private String s03s00;

    @TableField("s00s01f")
    private String s00s01f;

    @TableField("s02s02f")
    private String s02s02f;

    @TableField("s00s05f")
    private String s00s05f;

    @TableField("s00s01")
    private String s00s01;

    @TableField("s00s00")
    private String s00s00;

    @TableField("s00s03")
    private String s00s03;

    @TableField("s01s01f")
    private String s01s01f;

    @TableField("s00s02")
    private String s00s02;

    @TableField("s00s05")
    private String s00s05;

    @TableField("s00s04")
    private String s00s04;

    @TableField("s01s05f")
    private String s01s05f;

    @TableField("s03s02f")
    private String s03s02f;

    @TableField("s04s02")
    private String s04s02;

    @TableField("s04s01")
    private String s04s01;

    @TableField("s04s00")
    private String s04s00;

    @TableField("s00s00f")
    private String s00s00f;

    @TableField("updateTime")
    private String updateTime;

    @TableField("s00s04f")
    private String s00s04f;

    @TableField("s99saf")
    private String s99saf;

    @TableField("s02s03f")
    private String s02s03f;

    @TableField("s04s02f")
    private String s04s02f;

    @TableField("s01s02")
    private String s01s02;

    @TableField("s01s01")
    private String s01s01;

    @TableField("s01s04")
    private String s01s04;

    @TableField("s01s00f")
    private String s01s00f;

    @TableField("s01s03")
    private String s01s03;

    @TableField("s05s02f")
    private String s05s02f;

    @TableField("s01s05")
    private String s01s05;

    @TableField("s03s03f")
    private String s03s03f;

    @TableField("s01s04f")
    private String s01s04f;
}
