package com.ruoyi.project.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.project.system.entityVo.Crslist;
import com.ruoyi.project.system.mapper.CrslistMapper;
import com.ruoyi.project.system.service.CrslistService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Service
public class CrslistServiceImpl extends ServiceImpl<CrslistMapper, Crslist> implements CrslistService {

}
