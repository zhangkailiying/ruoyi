package com.ruoyi.project.system.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.project.system.entityVo.Matchresultlist;


/**
 * <p>
 *  服务类
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
public interface MatchresultlistService extends IService<Matchresultlist> {

}
