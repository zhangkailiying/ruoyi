package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("hhadlist")
public class Hhadlist implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("matchId")
    private Long matchId;

    @TableField("a")
    private String a;

    @TableField("updateDate")
    private Date updateDate;

    @TableField("df")
    private String df;

    @TableField("d")
    private String d;

    @TableField("af")
    private String af;

    @TableField("h")
    private String h;

    @TableField("updateTime")
    private String updateTime;

    @TableField("hf")
    private String hf;

    @TableField("goalLine")
    private String goalLine;
}
