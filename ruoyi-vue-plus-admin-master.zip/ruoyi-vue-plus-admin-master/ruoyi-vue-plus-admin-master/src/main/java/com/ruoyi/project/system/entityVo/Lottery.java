package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("lottery")
public class Lottery implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("sectionsNo999")
    private String sectionsNo999;

    @TableField("goalLine")
    private Integer goalLine;

    @TableField("leagueName")
    private String leagueName;

    @TableField("sectionsNo1")
    private String sectionsNo1;

    @TableField("leagueBackColor")
    private String leagueBackColor;

    @TableField("winFlag")
    private String winFlag;

    @TableField("a")
    private String a;

    @TableField("d")
    private String d;

    @TableField("h")
    private String h;

    @TableField("allHomeTeam")
    private String allHomeTeam;

    @TableField("allAwayTeam")
    private String allAwayTeam;

    @TableField("matchDate")
    private String matchDate;

    @TableField("matchNumStr")
    private String matchNumStr;

    @TableField("matchId")
    private Long matchId;

    @TableField("awayTeamId")
    private Integer awayTeamId;

    @TableField("homeTeamId")
    private Integer homeTeamId;

    @TableField("leagueId")
    private Integer leagueId;

    @TableField("bettingSingle")
    private Integer bettingSingle;

    @TableField("poolStatus")
    private String poolStatus;

    @TableField("resultStatus")
    private String resultStatus;
}
