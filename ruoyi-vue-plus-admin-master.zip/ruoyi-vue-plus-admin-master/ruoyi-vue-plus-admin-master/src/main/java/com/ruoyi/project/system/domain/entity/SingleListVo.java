package com.ruoyi.project.system.domain.entity;

import lombok.Data;

@Data
public class SingleListVo {
    private int single;
    private String poolCode;
}
