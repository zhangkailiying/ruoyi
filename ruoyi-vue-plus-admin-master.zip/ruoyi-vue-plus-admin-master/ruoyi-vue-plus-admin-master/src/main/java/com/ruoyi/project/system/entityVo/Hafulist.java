package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("hafulist")
public class Hafulist implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("matchId")
    private Long matchId;

    @TableField("aa")
    private String aa;

    @TableField("dd")
    private String dd;

    @TableField("hh")
    private String hh;

    @TableField("updateDate")
    private Date updateDate;

    @TableField("adf")
    private String adf;

    @TableField("ad")
    private String ad;

    @TableField("dhf")
    private String dhf;

    @TableField("dh")
    private String dh;

    @TableField("aaf")
    private String aaf;

    @TableField("ah")
    private String ah;

    @TableField("ddf")
    private String ddf;

    @TableField("hhf")
    private String hhf;

    @TableField("daf")
    private String daf;

    @TableField("updateTime")
    private String updateTime;

    @TableField("hdf")
    private String hdf;

    @TableField("haf")
    private String haf;

    @TableField("goalLine")
    private String goalLine;

    @TableField("ha")
    private String ha;

    @TableField("hd")
    private String hd;

    @TableField("da")
    private String da;

    @TableField("ahf")
    private String ahf;
}
