package com.ruoyi.project.system.domain.entity;


/**
 * 详情 最后集成到主表中
 */
public class FootballDetil {







}
