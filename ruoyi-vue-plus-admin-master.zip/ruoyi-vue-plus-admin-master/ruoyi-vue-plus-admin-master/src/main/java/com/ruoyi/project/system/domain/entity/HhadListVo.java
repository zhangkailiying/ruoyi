package com.ruoyi.project.system.domain.entity;

import lombok.Data;

@Data
public class HhadListVo extends HadListVo {

//    private double a;
//    private String updateDate;
//    private int df;
//    private double d;
//    private int af;
//    private double h;
//    private String updateTime;
//    private int hf;
//    private String goalLine;
}
