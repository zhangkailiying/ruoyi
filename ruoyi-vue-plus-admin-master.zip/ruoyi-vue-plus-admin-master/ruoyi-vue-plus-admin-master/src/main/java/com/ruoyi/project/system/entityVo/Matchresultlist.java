package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("matchresultlist")
public class Matchresultlist implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("matchId")
    private Long matchId;

    @TableField("lineStatus")
    private String lineStatus;

    @TableField("poolTotals")
    private String poolTotals;

    @TableField("code")
    private String code;

    @TableField("oddsGoalLine")
    private String oddsGoalLine;

    @TableField("odds")
    private String odds;

    @TableField("combinationDesc")
    private String combinationDesc;

    @TableField("poolId")
    private Long poolId;

    @TableField("refundStatus")
    private String refundStatus;

    @TableField("oddsType")
    private String oddsType;

    @TableField("combination")
    private String combination;

    @TableField("goalLine")
    private String goalLine;
}
