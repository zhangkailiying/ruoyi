package com.ruoyi.project.system.domain.entity;

import lombok.Data;

import java.util.Date;


@Data
public class CrsListVo {
    private String s05s00;
//-1 使用 99替换
    private String s99sd;//平其他
    private String s02s00f;
    private String s99sh;//胜其他
    private String s01s00;
    private String s05s02;
    private String s05s01;
    private String s99sa;//平其他
    private String s00s03f;
    private String s02s04f;
    private String s04s01f;
    private String s03s00f;
    private String s01s03f;
    private String s02s04;
    private String s02s05;
    private String s02s02;
    private String s02s03;
    private String s05s01f;
    private String s02s00;
    private String s02s01;
    private String s02s05f;
    private String s00s02f;
    private String s02s01f;
    private String s04s00f;
    private String goalLine;
    private String s03s01f;
    private String s99sdf;
    private String s99shf;
    private String s01s02f;
    private String s03s03;
    private String s05s00f;
    private Date updateDate;
    private String s03s01;
    private String s03s02;
    private String s03s00;
    private String s00s01f;
    private String s02s02f;
    private String s00s05f;
    private String s00s01;
    private String s00s00;
    private String s00s03;
    private String s01s01f;
    private String s00s02;
    private String s00s05;
    private String s00s04;
    private String s01s05f;
    private String s03s02f;
    private String s04s02;
    private String s04s01;
    private String s04s00;
    private String s00s00f;
    private String updateTime;
    private String s00s04f;
    private String s99saf;
    private String s02s03f;
    private String s04s02f;
    private String s01s02;
    private String s01s01;
    private String s01s04;
    private String s01s00f;
    private String s01s03;
    private String s05s02f;
    private String s01s05;
    private String s03s03f;
    private String s01s04f;

}
