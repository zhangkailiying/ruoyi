package com.ruoyi.project.system.domain.entity;

import lombok.Data;

import java.util.Date;

@Data
public class HafuListVo {
    private String aa;
    private String dd;
    private String hh;
    private Date updateDate;
    private String adf;
    private String ad;
    private String dhf;
    private String dh;
    private String aaf;
    private String ah;
    private String ddf;
    private String hhf;
    private String daf;
    private String updateTime;
    private String hdf;
    private String haf;
    private String goalLine;
    private String ha;
    private String hd;
    private String da;
    private String ahf;
}
