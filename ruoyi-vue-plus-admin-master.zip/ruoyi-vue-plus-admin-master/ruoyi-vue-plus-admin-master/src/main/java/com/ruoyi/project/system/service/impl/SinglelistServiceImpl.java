package com.ruoyi.project.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.project.system.entityVo.Singlelist;
import com.ruoyi.project.system.mapper.SinglelistMapper;
import com.ruoyi.project.system.service.SinglelistService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Service
public class SinglelistServiceImpl extends ServiceImpl<SinglelistMapper, Singlelist> implements SinglelistService {

}
