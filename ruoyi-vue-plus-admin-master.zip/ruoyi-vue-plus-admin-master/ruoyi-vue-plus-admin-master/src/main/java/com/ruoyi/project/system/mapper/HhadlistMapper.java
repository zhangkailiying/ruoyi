package com.ruoyi.project.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.project.system.entityVo.Hhadlist;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
public interface HhadlistMapper extends BaseMapper<Hhadlist> {

}

