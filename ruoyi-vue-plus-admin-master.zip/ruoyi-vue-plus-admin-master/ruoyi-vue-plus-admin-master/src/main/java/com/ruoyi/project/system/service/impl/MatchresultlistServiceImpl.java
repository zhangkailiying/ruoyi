package com.ruoyi.project.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.project.system.entityVo.Matchresultlist;
import com.ruoyi.project.system.mapper.MatchresultlistMapper;
import com.ruoyi.project.system.service.MatchresultlistService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Service
public class MatchresultlistServiceImpl extends ServiceImpl<MatchresultlistMapper, Matchresultlist> implements MatchresultlistService {

}
