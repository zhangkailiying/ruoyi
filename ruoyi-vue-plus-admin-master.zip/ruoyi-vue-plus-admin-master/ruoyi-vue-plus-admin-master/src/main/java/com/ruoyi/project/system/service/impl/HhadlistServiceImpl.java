package com.ruoyi.project.system.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.project.system.entityVo.Hhadlist;
import com.ruoyi.project.system.mapper.HhadlistMapper;
import com.ruoyi.project.system.service.HhadlistService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Service
public class HhadlistServiceImpl extends ServiceImpl<HhadlistMapper, Hhadlist> implements HhadlistService {

}
