package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("oddshistory")
public class Oddshistory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 比赛id
     */
    @TableField("matchId")
    private Long matchId;

    @TableField("awayTeamAllName")
    private String awayTeamAllName;

    @TableField("awayTeamAbbName")
    private String awayTeamAbbName;

    @TableField("homeTeamAllName")
    private String homeTeamAllName;
//
//    @TableField("crsListId")
//    private Long crsListId;

    @TableField("homeTeamAbbName")
    private String homeTeamAbbName;
//
//    @TableField("hhadListId")
//    private Long hhadListId;
//
//    @TableField("ttgList")
//    private Long ttgList;

    @TableField("leagueAbbName")
    private String leagueAbbName;

    @TableField("leagueId")
    private String leagueId;
//
//    @TableField("singleListId")
//    private Long singleListId;

    @TableField("leagueAllName")
    private String leagueAllName;

//    @TableField("hadListId")
//    private Long hadListId;

    @TableField("homeTeamId")
    private Integer homeTeamId;

    @TableField("awayTeamId")
    private Integer awayTeamId;
//
//    @TableField("hafuListId")
//    private Long hafuListId;
}
