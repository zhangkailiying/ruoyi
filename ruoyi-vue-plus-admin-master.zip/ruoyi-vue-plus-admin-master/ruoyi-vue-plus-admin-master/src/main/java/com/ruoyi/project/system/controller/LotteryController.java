package com.ruoyi.project.system.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.R;
import com.ruoyi.common.utils.bean.BeanUtils;
import com.ruoyi.project.system.domain.entity.*;
import com.ruoyi.project.system.entityVo.*;
import com.ruoyi.project.system.service.*;
import lombok.extern.slf4j.Slf4j;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Slf4j
@RestController
@RequestMapping("/lottery")
public class LotteryController {

    @Resource
    private LotteryService lotteryService;

    @Resource
    private CrslistService crslistService;

    @Resource
    private MatchresultlistService matchresultlistService;

    @Resource
    private OddshistoryService oddshistoryService;

    @Resource
    private SinglelistService singlelistService;
    @Resource
    private TtglistService ttglistService;

    @Resource
    private HadlistService hadlistService;

    @Resource
    private HafulistService hafulistService;

    @Resource
    private HhadlistService hhadlistService;

    //循环调用
    @GetMapping("/lotteryList")
    public R list() throws InterruptedException {

        saveLotteryByDate("2025-03-09","2025-03-09");
        return R.ok("123");

    }

   //数据初始化完成后开始进行 每日正常拉取 目前初始化2025年的数据 之后会初始话2024年数据做参考
   private void saveLotteryByDate(String startDateStr,String endDateStr) throws InterruptedException{

       // 定义起始日期和结束日期
       try {
           List<Lottery> list = getLotterys(startDateStr,endDateStr);
           saveffff(list);
       } catch (InterruptedException e) {
           e.printStackTrace();
       }
//       DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//        startDateStr = "2025-03-09";
//        endDateStr = "2025-03-09";
//       // 将字符串解析为 LocalDate 对象
//       LocalDate startDate = LocalDate.parse(startDateStr, formatter);
//       LocalDate endDate = LocalDate.parse(endDateStr, formatter);
//
//       // 获取日期集合
//       List<String> dateList = getDateList(startDate, endDate);
//       //循环时间
//       dateList.stream().forEach(s -> {
//           LocalDate date = LocalDate.parse(s, formatter);
//           // 当前日期加一天
//           LocalDate nextDate = date.plusDays(1);
//           List<Lottery> list= null;
//           try {
//               list = getLotterys(s,nextDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
//               saveffff(list);
//           } catch (InterruptedException e) {
//               e.printStackTrace();
//           }
//
//       });



   }
   @Transactional
   private void saveffff(List<Lottery> list){
       lotteryService.saveBatch(list);
       list.stream().forEach(s->{
           try {
               getListEntityByType(s.getMatchId().toString());
           } catch (InterruptedException e) {
               e.printStackTrace();
           }
       });

   }

    private   List<String> getDateList(LocalDate startDate, LocalDate endDate) {
        List<String> dateList = new ArrayList<>();
        LocalDate currentDate = startDate;

        while (!currentDate.isAfter(endDate)) {
            dateList.add(currentDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            currentDate = currentDate.plusDays(1);
        }

        return dateList;
    }
    private static final int MIN_DELAY = 500; // 最小延迟毫秒
    private static final int MAX_DELAY = 2000; // 最大延迟毫秒
    private static final Random random = new Random();
    private static long getRandomDelay() {
        return (long) (MIN_DELAY + (MAX_DELAY - MIN_DELAY) * random.nextDouble());
    }

    /**
     * @param url 访问路径
     * @return
     */
    private static final String[] STRINGS = {"Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0"};
    public static Document getDocument(String url) throws InterruptedException {
        try {
            Thread.sleep(getRandomDelay());
            //随机轮询浏览器
            //5000是设置连接超时时间，单位ms          connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3");
           // return Jsoup.connect(url).userAgent("Mozilla/4.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)").ignoreContentType(true).timeout(5000).get();
            return Jsoup.connect(url).userAgent(getRandomString()).ignoreContentType(true).timeout(5000).get();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    public static String getRandomString() {
        // 随机选择一个索引
        int index = random.nextInt(STRINGS.length);
        // 返回该索引对应的字符串
        return STRINGS[index];
    }
    public static Document getDocument(int page) {
        try {
            String url = "http://www.cwl.gov.cn/cwl_admin/front/cwlkj/search/kjxx/findDrawNotice?name=3d&issueCount=&issueStart=&issueEnd=&dayStart=&dayEnd=&pageNo=" + page + "&pageSize=100&week=&systemType=PC";
            //5000是设置连接超时时间，单位ms
            return Jsoup.connect(url).timeout(5000).get();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    // 主数据保存
    public List<Lottery> getLotterys(String startDate, String endDate) throws InterruptedException {
        String URL="https://webapi.sporttery.cn/gateway/jc/football/getMatchResultV1.qry?matchPage=1";
        URL+=("&matchBeginDate="+startDate);
        URL+=("&matchEndDate="+endDate);
        URL+=("&leagueId=&pageSize=500&pageNo=1&isFix=0&pcOrWap=1");
        Document doc = getDocument(URL);
        JSONObject object = JSONObject.parseObject(doc.body().text());
        JSONObject object1 = JSONObject.parseObject(object.get("value").toString());
        List<Lottery> list=JSONObject.parseArray(object1.get("matchResult").toString(),Lottery.class);
        return list;
    }
 // 保存详细内容
    @Transactional
    public MatchDataVo getListEntityByType(String stringmatchId) throws InterruptedException {
        String URL="https://webapi.sporttery.cn/gateway/jc/football/getFixedBonusV1.qry?clientCode=3001&matchId="+stringmatchId;
        Document doc = getDocument(URL);
        JSONObject object = JSONObject.parseObject(doc.body().text());
        JSONObject object1 = JSONObject.parseObject(object.get("value").toString());
        MatchDataVo matchDataVo =JSONObject.parseObject(object1.toString().replace("s-1s","s99s"),MatchDataVo.class);
        Long   matchId=Long.valueOf(stringmatchId);
        log.info("matchId,{} ",matchId);
        log.info("打印对象信息, {}",matchDataVo);
        try {
            //分批保存对象
            //保存 Matchresultlist
            List<MatchResultListVo> matchResultListVoList=matchDataVo.getMatchResultList();
            List<Matchresultlist> matchResultList=new ArrayList<>();
            matchResultListVoList.stream().forEach(s->{
                Matchresultlist m=new Matchresultlist();
                BeanUtils.copyProperties(s,m);
                m.setMatchId(matchId);
                matchResultList.add(m);
            });
            matchresultlistService.saveBatch(matchResultList);

            //保存 OddsHistory
            OddsHistoryVo oddsHistoryvo=matchDataVo.getOddsHistory();
            Oddshistory oddshistory =new Oddshistory();
            oddshistory.setMatchId(matchId);
            oddshistory.setAwayTeamAbbName(oddsHistoryvo.getAwayTeamAbbName());
            oddshistory.setAwayTeamAllName(oddsHistoryvo.getAwayTeamAllName());
            oddshistory.setHomeTeamAbbName(oddsHistoryvo.getHomeTeamAbbName());
            oddshistory.setHomeTeamAllName(oddsHistoryvo.getHomeTeamAllName());
            oddshistory.setAwayTeamId(oddsHistoryvo.getAwayTeamId());
            oddshistory.setHomeTeamId(oddsHistoryvo.getHomeTeamId());
            oddshistory.setLeagueAbbName(oddsHistoryvo.getLeagueAbbName());
            oddshistory.setLeagueAllName(oddsHistoryvo.getLeagueAllName());
            oddshistory.setLeagueId(oddsHistoryvo.getLeagueId());
            oddshistoryService.save(oddshistory);

            //保存crslist
            List<CrsListVo> crsListVoList=oddsHistoryvo.getCrsList();
            List<Crslist> crslists=new ArrayList<>();
            crsListVoList.stream().forEach(s->{
                Crslist m=new Crslist();
                BeanUtils.copyProperties(s,m);
                m.setMatchId(matchId);
                crslists.add(m);
            });
            crslistService.saveBatch(crslists);
            //保存Hadlist
            List<HadListVo> hadListVos=oddsHistoryvo.getHadList();
            List<Hadlist> hadlists=new ArrayList<>();
            hadListVos.stream().forEach(s->{
                Hadlist m=new Hadlist();
                BeanUtils.copyProperties(s,m);
                m.setMatchId(matchId);
                m.setUpdateDate(s.getUpdateDate());
                hadlists.add(m);
            });
            hadlistService.saveBatch(hadlists);
            List<Hhadlist> hhadlists=new ArrayList<>();
            hadlists.stream().forEach(s->{
                Hhadlist m=new Hhadlist();
                BeanUtils.copyProperties(s,m);
                m.setUpdateDate(s.getUpdateDate());
                m.setMatchId(matchId);
                hhadlists.add(m);
            });
            hhadlistService.saveBatch(hhadlists);


            //保存 Hafulist
            List<HafuListVo> hadVoList=oddsHistoryvo.getHafuList();
            List<Hafulist> hafulists=new ArrayList<>();
            hadVoList.stream().forEach(s->{
                Hafulist m=new Hafulist();
                BeanUtils.copyProperties(s,m);
                m.setMatchId(matchId);
                m.setUpdateDate(s.getUpdateDate());
                hafulists.add(m);
            });
            hafulistService.saveBatch(hafulists);
            //保存 Singlelist
            List<SingleListVo> singleListVos=oddsHistoryvo.getSingleList();
            List<Singlelist> singlelists=new ArrayList<>();
            singleListVos.stream().forEach(s->{
                Singlelist m=new Singlelist();
                BeanUtils.copyProperties(s,m);
                m.setMatchId(matchId);
                singlelists.add(m);
            });

            singlelistService.saveBatch(singlelists);

            //保存 Ttglist
            List<TtgListVo> ttgListVos=oddsHistoryvo.getTtgList();
            List<Ttglist> ttglists=new ArrayList<>();
            ttgListVos.stream().forEach(s->{
                Ttglist m=new Ttglist();
                BeanUtils.copyProperties(s,m);
                m.setMatchId(matchId);
                ttglists.add(m);
            });
            ttglistService.saveBatch(ttglists);
        }catch (Exception e){
            log.error("保存异常， {}",e.getMessage());
        }

        return matchDataVo;
    }


    public static void saveBatchLotterys( List<Lottery> list) {

        String url = "jdbc:mysql://cd-cdb-mksu3lvw.sql.tencentcdb.com:27330/ruoyi?useUnicode=true&characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=true&serverTimezone=GMT%2B8";
        String user = "root";
        String password = "Zk5213344";
        Connection conn = null;
        String sql = "INSERT INTO tb_football(sectionsNo999,goalLine,leagueName,sectionsNo1,leagueBackColor,winFlag,a,d,h,allHomeTeam,allAwayTeam,matchDate,matchNumStr,awayTeamId,homeTeamId,leagueId) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        //历史奖地址 https://m.zhuying.com/api/lotapi/selectListV2
        try {
            //加载jdbc驱动
            Class.forName("com.mysql.cj.jdbc.Driver");
            //连接mysql
            try {
                conn = DriverManager.getConnection(url, user, password);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            //将自动提交关闭
            conn.setAutoCommit(false);
            //编写sql
            PreparedStatement pstm = conn.prepareStatement(sql);

            list.stream().forEach(lottery -> {
                try {
                    pstm.setString(1,lottery.getSectionsNo999());
                    pstm.setString(2,lottery.getGoalLine().toString());
                    pstm.setString(3, lottery.getLeagueName());
                    pstm.setString(4, lottery.getSectionsNo1());
                    pstm.setString(5, lottery.getLeagueBackColor());
                    pstm.setString(6, lottery.getWinFlag());
                    pstm.setString(7, lottery.getA());
                    pstm.setString(8, lottery.getD());
                    pstm.setString(9, lottery.getH());
                    pstm.setString(10, lottery.getAllHomeTeam());
                    pstm.setString(11, lottery.getAllAwayTeam());
                    pstm.setString(12, lottery.getMatchDate());
                    pstm.setString(13, lottery.getMatchNumStr());
                    pstm.setInt(14, lottery.getAwayTeamId());
                    pstm.setInt(15, lottery.getHomeTeamId());
                    pstm.setInt(16, lottery.getLeagueId());
                    pstm.addBatch();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            //添加到同一个批处理
            pstm.executeBatch();
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
