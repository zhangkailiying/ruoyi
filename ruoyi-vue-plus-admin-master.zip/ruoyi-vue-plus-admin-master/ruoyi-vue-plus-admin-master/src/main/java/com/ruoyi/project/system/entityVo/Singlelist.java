package com.ruoyi.project.system.entityVo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author Baomidou
 * @since 2025-03-07
 */
@Data
@TableName("singlelist")
public class Singlelist implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("matchId")
    private Long matchId;

    @TableField("single")
    private Integer single;

    @TableField("poolCode")
    private String poolCode;
}
