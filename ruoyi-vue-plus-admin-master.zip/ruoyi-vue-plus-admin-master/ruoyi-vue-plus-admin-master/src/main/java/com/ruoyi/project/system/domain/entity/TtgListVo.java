package com.ruoyi.project.system.domain.entity;

import lombok.Data;

import java.util.Date;
@Data
public class TtgListVo {
    private String s3;
    private String s4;
    private Date updateDate;
    private String s5;
    private String s6f;
    private String s6;
    private String s7f;
    private String s4f;
    private String s7;
    private String s5f;
    private String s2f;
    private String s3f;
    private String s0f;
    private String s1f;
    private String updateTime;
    private String goalLine;
    private String s0;
    private String s1;
    private String s2;
}
