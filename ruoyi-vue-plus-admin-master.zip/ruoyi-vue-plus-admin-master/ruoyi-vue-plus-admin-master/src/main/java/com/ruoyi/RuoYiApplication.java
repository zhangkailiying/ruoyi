package com.ruoyi;

import cn.hutool.core.net.NetUtil;
import cn.hutool.core.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

/**
 * 启动程序
 * 
 * @author ruoyi
 */
@Slf4j
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
public class RuoYiApplication
{
    public static void main(String[] args) {
        ConfigurableApplicationContext application = SpringApplication.run(RuoYiApplication.class, args);
        Environment env = application.getEnvironment();
        String ip = NetUtil.getLocalhost().getHostAddress();
        String port = StrUtil.nullToDefault(env.getProperty("server.port"), "8080");
        String path = StrUtil.nullToEmpty(env.getProperty("server.servlet.context-path"));
        StringBuilder builder = new StringBuilder();
        builder.append("\n----------------------------------------------------------\n\t");
        builder.append("      Local: http://localhost:" + port + path + "/\n\t");
        builder.append("   External: http://" + ip + ":" + port + path + "/\n\t");
        builder.append("    Swagger: http://" + ip + ":" + port + path + "/swagger-ui.html\n\t");
        builder.append("Swagger Api: http://" + ip + ":" + port + path + "/v2/api-docs\n");
        builder.append("----------------------------------------------------------");
        log.info(builder.toString());
    }
}
