package com.ruoyi.project.cstest.service;

import com.ruoyi.project.cstest.domain.CsTest;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * 测试Service接口
 *
 * @author Lion Li
 * @date 2020-05-12
 */
public interface ICsTestService extends IService<CsTest> {

}
