package com.ruoyi.project.system.domain.entity;

import lombok.Data;

import java.util.Date;

@Data
public class HadListVo {
    private String a;
    private Date updateDate;
    private String df;
    private String d;
    private String af;
    private String h;
    private String updateTime;
    private String hf;
    private String goalLine;
}
