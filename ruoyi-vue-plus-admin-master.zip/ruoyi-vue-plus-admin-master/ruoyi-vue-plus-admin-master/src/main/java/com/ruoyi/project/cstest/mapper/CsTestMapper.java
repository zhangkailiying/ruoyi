package com.ruoyi.project.cstest.mapper;

import com.ruoyi.project.cstest.domain.CsTest;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 测试Mapper接口
 *
 * @author Lion Li
 * @date 2020-05-12
 */
public interface CsTestMapper extends BaseMapper<CsTest> {

}
